#ifdef NEW_TMVA_API
#include "TMVA/DataLoader.h"
typedef TMVA::DataLoader TMVA_Object;
#else
#include "TMVA/Factory.h"
typedef TMVA::Factory TMVA_Object;
#endif
